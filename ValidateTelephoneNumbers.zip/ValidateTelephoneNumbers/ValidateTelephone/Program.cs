﻿using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;

/// <summary>
/// Class to display the count of all the valid phone numbers in a file
/// </summary>
public class Program
{
    /// <summary>
    /// Main method to execute the program
    /// </summary>
    public static void Main()
    {
        try
        {
            //Getting the path of the testcases
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string path = currentDirectory.Replace("\\bin\\Debug\\net7.0\\", "\\Testcases\\Data.txt");
            List<string> telephoneNumbers = File.ReadAllLines(path).ToList();

            //To check if the file is empty
            if (telephoneNumbers.Count == 0)
            {
                Console.WriteLine("File is empty");
                return;
            }
            telephoneNumbers = IsValidPhoneNum(telephoneNumbers);
            //To check if the file contains any valid telephone numbers
            if (telephoneNumbers.Count == 0)
            {
                Console.WriteLine("List does not contain any valid telephone numbers");
                return;
            }
            PrintOccurences(telephoneNumbers);
        }
        catch (Exception ex)
        {

            Console.WriteLine(ex.Message);
        }


    }

   
    /// <summary>
    /// To validate phone numbers format
    /// </summary>
    /// <param name="files">List of phone numbers</param>
    /// <returns>valid list of phone numbers</returns>
    public static List<string> IsValidPhoneNum(List<string> files)
    {
        //Pattern to detect all valid telephone number as per XXX-XXX-XXXX
        string motif = @"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$";

        //To remove the invalid telephone numbers
        List<string> toRemove = new List<string>();
        foreach (string number in files)
        {
            if (number != null)
            {
               if( !Regex.IsMatch(number, motif))
                {
                    toRemove.Add(number);
                }
            }
        }
        //Removes all the invalid numbers
        files.RemoveAll(x => toRemove.Contains(x));
        return files;
    }

    /// <summary>
    /// Prints all the valid telephone numbers along with the occurences
    /// </summary>
    /// <param name="files">List of valid telephone numbers</param>
    public static void PrintOccurences(List<string> files)
    {
        //Groups the numbers and stores the count of the occurences
        var resultSet = files.GroupBy(x => x)
            .ToDictionary(y => y.Key, y => y.Count())
            .OrderByDescending(z => z.Value);

        //To display the output
        foreach (var phonenumberCount in resultSet)
        {
            Console.WriteLine("Telephone Number: " + phonenumberCount.Key + " Count of Occurences: " + phonenumberCount.Value);
        }

    }
}